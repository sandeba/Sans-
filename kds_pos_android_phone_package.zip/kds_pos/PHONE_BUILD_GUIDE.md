# Build KDS POS APK using only an Android phone

This route uses GitHub in your phone browser. The build happens on GitHub's cloud runner; your phone does not need Flutter or Android Studio installed.

## 1. Create a GitHub repository
1. Open https://github.com in Chrome and sign in (create a free account if needed).
2. Tap **+** → **New repository**.
3. Name it `kds-pos`, choose **Private**, and create it.
4. Upload the contents of this project (the `lib` folder, `pubspec.yaml`, `analysis_options.yaml`, `.gitignore`, `.github` folder and this README) using **Add file → Upload files**. Commit the upload to `main`.

## 2. Run the cloud build
1. Open the repository's **Actions** tab.
2. Select **Build Android APK**.
3. Tap **Run workflow** → **Run workflow**.
4. Wait for the run to finish successfully. If it fails, open the run and inspect the failing step; do not install an APK from a failed run.

## 3. Download and install
1. Open the successful workflow run.
2. Scroll to **Artifacts** and download `kds-pos-android-apk`.
3. Extract the ZIP on your phone (Files app → Downloads → ZIP → Extract).
4. Tap `app-release.apk` and allow Chrome/Files to install apps from this source if Android asks. Only install APKs from your own successful build.

## Notes
- The first build generates the standard Android project files using `flutter create` in the cloud.
- Keep the repository private because the source contains a development POS prototype.
- Demo accounts in this MVP: admin / 1234, manager / 2222, cashier / 3333. Change these before real shop use.
- This is an MVP, not yet production-hardened. M-Pesa is manual reference recording, not live Safaricom payment verification. Bluetooth ESC/POS printing and cloud sync are not yet connected. PDF receipts use Android's print/share flow.
- Never use the demo PINs for real transactions. Add secure PIN hashing, role enforcement, backup/restore, tested Bluetooth printer support, debt-payment allocation and proper accounting controls before production deployment.
