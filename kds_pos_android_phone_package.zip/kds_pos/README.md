# KIPLANGAT & DAUGHTERS' STORES POS

Offline-first Flutter Android POS MVP.

## Included in this MVP
- Local SQLite database for offline sales and inventory.
- Demo sign-in roles: Admin, Manager, Cashier.
- Branch selection and branch-specific products, sales, expenses and reports.
- Product setup and stock deduction at checkout.
- Cash, manual M-Pesa reference, card and credit payment recording.
- Customer list and balances.
- Expense recording.
- Sales, cost of goods sold, gross profit, expenses and estimated net profit report.
- PDF receipt generation through Android print/share flow.

## Demo login (development only)
- admin / 1234
- manager / 2222
- cashier / 3333

These are development credentials. Do not use them in a live shop. Secure PIN hashing and full role enforcement are required before production.

## Build using only an Android phone
See [PHONE_BUILD_GUIDE.md](PHONE_BUILD_GUIDE.md). A GitHub Actions workflow is included at `.github/workflows/android-apk.yml`; it creates Android platform files and builds a release APK in the cloud.

## Build locally
With Flutter stable and Android SDK installed:

```bash
flutter create . --platforms=android --org ke.co.kds
flutter pub get
flutter analyze
flutter build apk --release
```

APK output: `build/app/outputs/flutter-apk/app-release.apk`.

## Not yet production-ready
- Bluetooth thermal ESC/POS printing is not wired in this MVP.
- Online/cloud synchronization is not connected.
- M-Pesa is manual transaction-reference recording; no Daraja STK Push or payment verification.
- Profit reports are estimates and do not yet account for tax, returns, discounts, stock adjustments, supplier purchases or accounting periods.
- Secure user management, product editing/barcode scanning, debt-payment allocation, stock purchasing/receiving, backup/restore, and accounting controls remain future work.
